meal = 44.50
tax = 6.25/100
tip = 15.0/100

meal = meal + meal*tax
total = meal + meal*tip
print (total)