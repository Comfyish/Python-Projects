"""
Description: Miscrit nostalgia goes hard
Author: Comfumi
Title: Miscrit era
"""

# The template for the story

STORY = "The new player %s spawned in feeling %s. 'Today I will catch me some %s miscrits' Out in the forest, a bunch of %ss were battling over a %s. A random Flue joined in and used %s to the rhythm of the %s, this quickly alerted all the %ss of the incoming %s boss. Next, %s challenged %s, who used %s to start the rumbling in %s and transformed into a %s only to splice into a pair of sentient %s. %s took %s direct attacks from %s."

print ("Mad Libs has started!")
name = input("Enter a name: ")
adj1 = input("Enter an adjective: ")
adj2 = input("Enter another adjective: ")
adj3 = input("Enter one last adjective: ")
verb = input("Now please enter a verb: ")
noun1 = input("Okay now give me a noun: ")
noun2 = input("And another noun: ")
animal = input("Type in a animal: ")
food = input("Enter a food: ")
fruit = input("Enter a fruit: ")
hero = input("Enter the name of a superhero: ")
country = input("Enter the name of a country: ")
dessert = input("Enter a dessert: ")
year= input("Enter a year: ")
print (STORY % (name, adj1, adj2, animal, food, verb, noun1, fruit, adj3, name, hero, name, country, name, dessert, name, year, noun2))




















